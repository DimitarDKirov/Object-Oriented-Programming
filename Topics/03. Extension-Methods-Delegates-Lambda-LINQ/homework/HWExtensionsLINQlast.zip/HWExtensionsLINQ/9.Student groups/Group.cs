﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_groups
{
    class Group
    {
        public string DepartmentName { get; set; }
        public int GroupNumber { get; set; }
    }
}
